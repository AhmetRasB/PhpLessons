### [Cmder](http://cmder.net/)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/cmder/archive/master.zip) option

* Open your cmder
* Click Win+Alt+P
* Click in Import
* Select the Dracula.xml
* Save Settings